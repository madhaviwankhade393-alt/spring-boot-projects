package com.learning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbJpaQueryExecutionApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbJpaQueryExecutionApplication.class, args);
	}

}
